package model;

public enum PetType {
    DOG,
    CAT,
    FISH,
    FROG,
    BIRD,
    RAT,
    ROCK
}
