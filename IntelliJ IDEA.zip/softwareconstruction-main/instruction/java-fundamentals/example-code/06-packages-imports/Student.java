package edu.byu.cs;

public class Student {
}
