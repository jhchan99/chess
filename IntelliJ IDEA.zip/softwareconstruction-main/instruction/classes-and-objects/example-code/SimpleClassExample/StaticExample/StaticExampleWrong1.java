package StaticExamples;

public class StaticExampleWrong1 {

    private int myInstanceVariable;

    public static void main(String [] args) {
//        myInstanceVariable = 10;
//        myInstanceMethod();
    }

    public void myInstanceMethod() {

    }
}
