# Title

🖥️ [Slides]()

📖 **Required Reading**: Core Java for the Impatient

- Chapter x:

blurb

## Things to Understand

- x
- x

## Videos

- 🎥 [x]()

## Demonstration code

📁 [x](example-code/)
