package nestedClassExample;

public interface Iterator {

    boolean hasNext();

    int getNext();
}
