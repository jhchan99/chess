public class KeyValuePair<V> extends Pair<String, V> {
    public KeyValuePair(String value1, V value2) {
        super(value1, value2);
    }
}
