package interfaceExample;

public interface Function<T, R> {
    R apply(T param);
}
