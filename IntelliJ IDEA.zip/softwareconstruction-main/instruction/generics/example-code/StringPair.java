public class StringPair extends Pair<String, String> {
    public StringPair(String value1, String value2) {
        super(value1, value2);
    }
}
