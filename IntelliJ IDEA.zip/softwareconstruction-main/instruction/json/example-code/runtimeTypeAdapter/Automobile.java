public interface Automobile {
    String getMake();
    String getModel();
    int getYear();
}
